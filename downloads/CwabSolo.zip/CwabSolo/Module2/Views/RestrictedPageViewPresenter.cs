﻿using System;
using Microsoft.Practices.CompositeWeb;

namespace Module2.Views
{
	public class RestrictedPageViewPresenter : Presenter<IRestrictedPageView>
	{
	}
}
