﻿using System;

namespace Module2.Views
{
	public interface IUnrestrictedPageView
	{
	}
}
