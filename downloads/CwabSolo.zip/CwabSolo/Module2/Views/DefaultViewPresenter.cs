﻿using System;
using Microsoft.Practices.CompositeWeb;

namespace Module2.Views
{
	public class DefaultViewPresenter : Presenter<IDefaultView>
	{
	}
}
