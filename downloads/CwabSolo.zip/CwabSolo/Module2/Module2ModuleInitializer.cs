﻿using System;
using Microsoft.Practices.CompositeWeb;
using Microsoft.Practices.CompositeWeb.Interfaces;
using Navigation.Services;

namespace Module2
{
	public class Module2ModuleInitializer : Framework.ViewModuleInitializer
	{
		ISiteMapNodeInfoLocator _siteMapNodeInfoLocator;

		protected override void AddGlobalServices(IServiceCollection globalServices)
		{
			// No global services to register.
		}

		protected override void AddModuleServices(IServiceCollection moduleServices)
		{
			// No module services to register.
		}

		protected override void RegisterSiteMapInformation(ISiteMapBuilderService siteMapBuilderService)
		{
			SiteMapNodeInfo moduleNode = new SiteMapNodeInfo("Module2", "~/Module2/Default.aspx", "Module 2");
			siteMapBuilderService.AddNode(moduleNode);

			SiteMapNodeInfo pageNode = new SiteMapNodeInfo("Module2.UnrestrictedPage", "~/Module2/UnrestrictedPage.aspx", "Module 2 Unrestricted");
			siteMapBuilderService.AddNode(pageNode, moduleNode);

			SiteMapNodeInfo restrictedNode = this._siteMapNodeInfoLocator.FindSiteMapNodeInfoFromKey("Restricted");
			pageNode = new SiteMapNodeInfo("Module2.RestrictedPage", "~/Module2/Restricted/RestrictedPage.aspx", "Module 2 Restricted");
			siteMapBuilderService.AddNode(pageNode, restrictedNode);
		}

		[ServiceDependency]
		public ISiteMapNodeInfoLocator SiteMapNodeInfoLocator
		{
			set
			{
				_siteMapNodeInfoLocator = value;
			}
		}
	}
}
