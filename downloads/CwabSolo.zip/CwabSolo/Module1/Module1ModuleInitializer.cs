﻿using System;
using Microsoft.Practices.CompositeWeb;
using Microsoft.Practices.CompositeWeb.Interfaces;
using Navigation.Services;

namespace Module1
{
	public class Module1ModuleInitializer : Framework.ViewModuleInitializer
	{
		ISiteMapNodeInfoLocator _siteMapNodeInfoLocator;

		protected override void AddGlobalServices(IServiceCollection globalServices)
		{
			// No global services to register.
		}

		protected override void AddModuleServices(IServiceCollection moduleServices)
		{
			// No module services to register.
		}

		protected override void RegisterSiteMapInformation(ISiteMapBuilderService siteMapBuilderService)
		{
			SiteMapNodeInfo moduleNode = new SiteMapNodeInfo("Module1", "~/Module1/Default.aspx", "Module 1");
			siteMapBuilderService.AddNode(moduleNode);

			SiteMapNodeInfo pageNode = new SiteMapNodeInfo("Module1.UnrestrictedPage", "~/Module1/UnrestrictedPage.aspx", "Module 1 Unrestricted");
			siteMapBuilderService.AddNode(pageNode, moduleNode);

			SiteMapNodeInfo restrictedNode = this._siteMapNodeInfoLocator.FindSiteMapNodeInfoFromKey("Restricted");
			pageNode = new SiteMapNodeInfo("Module1.RestrictedPage", "~/Module1/Restricted/RestrictedPage.aspx", "Module 1 Restricted");
			siteMapBuilderService.AddNode(pageNode, restrictedNode);
		}

		[ServiceDependency]
		public ISiteMapNodeInfoLocator SiteMapNodeInfoLocator
		{
			set
			{
				_siteMapNodeInfoLocator = value;
			}
		}
	}
}
