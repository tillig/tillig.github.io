﻿using System;
using Microsoft.Practices.CompositeWeb;

namespace Module1.Views
{
	public class UnrestrictedPageViewPresenter : Presenter<IUnrestrictedPageView>
	{
	}
}
