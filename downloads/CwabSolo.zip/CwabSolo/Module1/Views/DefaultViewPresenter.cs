﻿using System;
using Microsoft.Practices.CompositeWeb;

namespace Module1.Views
{
	public class DefaultViewPresenter : Presenter<IDefaultView>
	{
	}
}
