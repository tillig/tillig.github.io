﻿using System;

namespace Module1.Views
{
	public interface IUnrestrictedPageView
	{
	}
}
