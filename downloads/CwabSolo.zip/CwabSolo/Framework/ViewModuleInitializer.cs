﻿using System;
using Microsoft.Practices.CompositeWeb;
using Microsoft.Practices.CompositeWeb.Interfaces;

namespace Framework
{
	public abstract class ViewModuleInitializer : ServiceModuleInitializer
	{
		public override void Load(CompositionContainer container)
		{
			// UI modules add "module services" and site map information to
			// standard service modules.

			base.Load(container);
			this.AddModuleServices(container.Services);
			this.RegisterSiteMapInformation(container.Services.Get<ISiteMapBuilderService>(true));
		}

		protected override IServiceCollection LocateGlobalServiceContainer(CompositionContainer container)
		{
			// Global services in a UI module are in the parent container.
			return container.Parent.Services;
		}

		protected abstract void AddModuleServices(IServiceCollection moduleServices);

		// All UI modules have site map information to register.
		protected abstract void RegisterSiteMapInformation(ISiteMapBuilderService siteMapBuilderService);
	}
}
