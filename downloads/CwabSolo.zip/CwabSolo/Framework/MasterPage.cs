﻿using System;
using Microsoft.Practices.ObjectBuilder;
using Microsoft.Practices.CompositeWeb;
using Microsoft.Practices.CompositeWeb.Web.UI;

namespace Framework
{
	// There doesn't seem to be a constraint to say
	// "This view also needs to implement the TViewInterface interface."
	// Instead, we check it in the Presenter setter.
	public class MasterPage<TPresenter, TViewInterface> : MasterPage
		where TPresenter : Presenter<TViewInterface>
		where TViewInterface : class
	{
		private TPresenter _presenter;

		protected override void OnInit(EventArgs e)
		{
			base.OnInit(e);
			this.Load += new EventHandler(View_Load);
		}

		void View_Load(object sender, EventArgs e)
		{
			if (!this.IsPostBack)
			{
				this.Presenter.OnViewInitialized();
			}
			this.Presenter.OnViewLoaded();
		}

		[CreateNew]
		public TPresenter Presenter
		{
			get
			{
				return this._presenter;
			}
			set
			{
				if (value == null)
				{
					throw new ArgumentNullException("value");
				}
				if (!(this is TViewInterface))
				{
					throw new System.InvalidOperationException(String.Format("The master page must implement the {0} interface.", typeof(TViewInterface).FullName));
				}
				this._presenter = value;
				this._presenter.View = this as TViewInterface;
			}
		}
	}
}
