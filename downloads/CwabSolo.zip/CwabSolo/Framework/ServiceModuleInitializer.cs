﻿using System;
using Microsoft.Practices.CompositeWeb;
using Microsoft.Practices.CompositeWeb.Interfaces;

namespace Framework
{
	public abstract class ServiceModuleInitializer : ModuleInitializer
	{
		public override void Load(CompositionContainer container)
		{
			// This progression of calling base, then adding global services...
			// that's common to all modules.

			base.Load(container);

			this.AddGlobalServices(this.LocateGlobalServiceContainer(container));
		}

		protected virtual IServiceCollection LocateGlobalServiceContainer(CompositionContainer container)
		{
			return container.Services;
		}

		// Every service module has global services to register.
		protected abstract void AddGlobalServices(IServiceCollection globalServices);

		// If we were using the Security Application Block for authorization, we'd
		// override the Configure method and configure the authorization rules service.
	}
}
