﻿using System;
using Microsoft.Practices.CompositeWeb;
using Microsoft.Practices.CompositeWeb.Interfaces;
using Microsoft.Practices.CompositeWeb.Services;

namespace Core
{
	public class CoreModuleInitializer : Framework.ViewModuleInitializer
	{
		protected override void AddGlobalServices(IServiceCollection globalServices)
		{
			// Not registering the EnterpriseLibraryAuthorizationService that usually
			// gets registered in typical CWAB "Shell" modules.
			
			// Registering the site map builder service so we can aggregate a
			// site map by module.
			globalServices.AddNew<SiteMapBuilderService, ISiteMapBuilderService>();
		}

		protected override void AddModuleServices(IServiceCollection moduleServices)
		{
			// No module services to register.
		}

		protected override void RegisterSiteMapInformation(ISiteMapBuilderService siteMapBuilderService)
		{
			SiteMapNodeInfo moduleNode = new SiteMapNodeInfo("Home", "~/Default.aspx", "Home");
			siteMapBuilderService.AddNode(moduleNode);

			siteMapBuilderService.RootNode.Url = "~/Default.aspx";
			siteMapBuilderService.RootNode.Title = "WebApplication";

			SiteMapNodeInfo restrictedNode = new SiteMapNodeInfo("Restricted", "~/Restricted.aspx", "Restricted");
			siteMapBuilderService.AddNode(restrictedNode);
		}
	}
}
