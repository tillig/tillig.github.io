﻿using System;
using System.Collections.Specialized;
using System.Web;

namespace Core.Services
{
	public class LocationAuthorizationSiteMapProvider : Microsoft.Practices.CompositeWeb.Providers.ModuleSiteMapProvider
	{
		private BasicSiteMapProvider _basicProvider = new BasicSiteMapProvider();

		public override void Initialize(string name, NameValueCollection attributes)
		{
			NameValueCollection passThroughAttributes = new NameValueCollection();
			foreach (string key in attributes.Keys)
			{
				passThroughAttributes.Add(key, attributes[key]);
			}
			this._basicProvider.Initialize(name, passThroughAttributes);
			base.Initialize(name, attributes);
		}

		protected override bool IsAccessibleToUser(SiteMapNode node)
		{
			// We need to override because we can't call "base.base.IsAccessibleToUser"
			// but that's the behavior we want.
			//
			// Also note that we should be using the IHttpContextLocatorService here
			// to retrieve the current context, but you can't cast the CWAB
			// IHttpContext interface to a standard HttpContext and you can't get
			// to the underlying concrete implementation through the wrapper.
			return this._basicProvider.IsAccessibleToUser(HttpContext.Current, node);
		}

		/// <summary>
		/// Site map provider used only for the basic authorization features.
		/// If they made that stuff <see langword="static" /> or exposed
		/// the auth stuff publicly, we wouldn't need this.
		/// </summary>
		private class BasicSiteMapProvider : SiteMapProvider
		{
			public override SiteMapNode FindSiteMapNode(string rawUrl)
			{
				throw new NotImplementedException();
			}

			public override SiteMapNodeCollection GetChildNodes(SiteMapNode node)
			{
				throw new NotImplementedException();
			}

			public override SiteMapNode GetParentNode(SiteMapNode node)
			{
				throw new NotImplementedException();
			}

			protected override SiteMapNode GetRootNodeCore()
			{
				throw new NotImplementedException();
			}
		}
	}
}
