﻿using System;
using Microsoft.Practices.CompositeWeb;

namespace Core.Views
{
	public class DefaultViewPresenter : Presenter<IDefaultView>
	{
	}
}
