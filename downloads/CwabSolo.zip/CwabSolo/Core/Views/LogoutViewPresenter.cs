﻿using System;
using Microsoft.Practices.CompositeWeb;

namespace Core.Views
{
	public class LogoutViewPresenter : Presenter<ILogoutView>
	{
	}
}
