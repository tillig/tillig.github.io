﻿using System;

namespace Core.Views
{
	public interface IDefaultView
	{
	}
}
