﻿using System;
using Microsoft.Practices.CompositeWeb;

namespace Core.MasterPages
{
	public class DefaultMasterPresenter : Presenter<IDefaultMasterView>
	{
	}
}




