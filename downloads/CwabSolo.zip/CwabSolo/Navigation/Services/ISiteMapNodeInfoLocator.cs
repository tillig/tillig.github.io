﻿using System;
using Microsoft.Practices.CompositeWeb;

namespace Navigation.Services
{
	public interface ISiteMapNodeInfoLocator
	{
		SiteMapNodeInfo RootNode { get; }
		SiteMapNodeInfo FindSiteMapNodeInfoFromKey(string key);
	}
}
