﻿using System;
using System.Collections.ObjectModel;
using Microsoft.Practices.CompositeWeb;
using Microsoft.Practices.CompositeWeb.Interfaces;
using Microsoft.Practices.ObjectBuilder;

namespace Navigation.Services
{
	public class SiteMapNodeInfoLocator : ISiteMapNodeInfoLocator
	{
		ISiteMapBuilderService _siteMapBuilderService;

		// The [ServiceDependency] attribute here is VERY IMPORTANT. It's different
		// than the standard ObjectBuilder [Dependency] attribute and works against
		// registered services, not just any dependencies. This is a HUGE difference
		// that will cause a lot of frustration if you don't get it right.
		public SiteMapNodeInfoLocator([ServiceDependency] ISiteMapBuilderService siteMapBuilderService)
		{
			this._siteMapBuilderService = siteMapBuilderService;
		}

		public SiteMapNodeInfo RootNode
		{
			get
			{
				return this._siteMapBuilderService.RootNode;
			}
		}

		public SiteMapNodeInfo FindSiteMapNodeInfoFromKey(string key)
		{
			return this.RecursiveTreeSearch(this.RootNode, key);
		}

		private SiteMapNodeInfo RecursiveTreeSearch(SiteMapNodeInfo root, string key)
		{
			if (root == null)
			{
				return null;
			}
			if (root.Key == key)
			{
				return root;
			}
			ReadOnlyCollection<SiteMapNodeInfo> children = this._siteMapBuilderService.GetChildren(root.Key);
			foreach (SiteMapNodeInfo child in children)
			{
				SiteMapNodeInfo found = this.RecursiveTreeSearch(child, key);
				if (found != null)
				{
					return found;
				}
			}
			return null;
		}
	}
}
