﻿using System;
using Navigation.Services;

namespace Navigation
{
	public class NavigationModuleInitializer : Framework.ServiceModuleInitializer
	{
		protected override void AddGlobalServices(Microsoft.Practices.CompositeWeb.Interfaces.IServiceCollection globalServices)
		{
			globalServices.AddNew<SiteMapNodeInfoLocator, ISiteMapNodeInfoLocator>();
		}
	}
}
