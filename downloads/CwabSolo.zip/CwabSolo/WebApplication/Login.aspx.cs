﻿using System;
using System.Web.Security;

namespace Core.Views
{
	public partial class Login : Framework.View<LoginViewPresenter, ILoginView>, ILoginView
	{
		protected void Login1_Authenticate(object sender, System.Web.UI.WebControls.AuthenticateEventArgs e)
		{
			// This code is necessary because we're not using membership. If we
			// were to use a membership provider, we wouldn't need a custom
			// authentication handler.
			string username = this.Login1.UserName;
			string password = this.Login1.Password;
			e.Authenticated = FormsAuthentication.Authenticate(username, password);
		}
	}
}
