﻿using System;

namespace Core.Views
{
	public partial class Restricted : Framework.View<RestrictedViewPresenter, IRestrictedView>, IRestrictedView
	{
	}
}
