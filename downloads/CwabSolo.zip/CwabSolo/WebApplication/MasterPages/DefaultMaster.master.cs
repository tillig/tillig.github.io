﻿using System;
using Core.MasterPages;

namespace Core.MasterPages
{
	public partial class DefaultMaster : Framework.MasterPage<DefaultMasterPresenter, IDefaultMasterView>, IDefaultMasterView
	{
	}
}
