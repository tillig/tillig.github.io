﻿using System;

namespace Module2.Views
{
	public partial class Default : Framework.View<DefaultViewPresenter, IDefaultView>, IDefaultView
	{
	}
}
