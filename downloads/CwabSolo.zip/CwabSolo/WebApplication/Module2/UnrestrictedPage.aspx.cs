﻿using System;

namespace Module2.Views
{
	public partial class UnrestrictedPage : Framework.View<UnrestrictedPageViewPresenter, IUnrestrictedPageView>, IUnrestrictedPageView
	{
	}
}
