﻿using System;

namespace Module2.Views
{
	public partial class RestrictedPage : Framework.View<RestrictedPageViewPresenter, IRestrictedPageView>, IRestrictedPageView
	{
	}
}
