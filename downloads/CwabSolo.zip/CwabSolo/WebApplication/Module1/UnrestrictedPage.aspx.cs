﻿using System;

namespace Module1.Views
{
	public partial class UnrestrictedPage : Framework.View<UnrestrictedPageViewPresenter, IUnrestrictedPageView>, IUnrestrictedPageView
	{
	}
}
