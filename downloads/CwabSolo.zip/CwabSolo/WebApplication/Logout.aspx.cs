﻿using System;

namespace Core.Views
{
	public partial class Logout : Framework.View<LogoutViewPresenter, ILogoutView>, ILogoutView
	{
	}
}
