﻿using System;

namespace Core.Views
{
	public partial class _Default : Framework.View<DefaultViewPresenter, IDefaultView>, IDefaultView
	{
	}
}
