To get this working, download the Web Client Software Factory here:
http://www.codeplex.com/websf
Then put Microsoft.Practices.CompositeWeb.dll and Microsoft.Practices.ObjectBuilder.dll into the "Library" folder.