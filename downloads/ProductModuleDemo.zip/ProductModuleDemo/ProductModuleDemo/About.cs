﻿using System;
using System.Reflection;

namespace ProductModuleDemo
{
	public class About : DevExpress.CodeRush.Common.ProductModule
	{
		// TODO: Create your own logo and embed it as a resource.
		private const string LogoPath = "ProductModuleDemo.ProductModuleLogo.png";
		// TODO: Make sure you use YOUR OWN GUID.
		private static readonly Guid ProductId = new Guid("0CB93ADC-7188-4632-B469-98D161074E48");
		// TODO: Make sure the minimum DXCore version is set properly for your plugin.
		private static DevExpress.CodeRush.Common.Version MinEngineVersion = new DevExpress.CodeRush.Common.Version(10, 1, 6, 0);
		// TODO: Set this value to the actual name of your plugin assembly.
		private const string PluginAssemblyName = "ProductModuleDemo.dll";

		private static readonly string AssemblyTitle;
		private static readonly string AssemblyCopyright;
		private static readonly string AssemblyDescription;
		private static readonly DevExpress.CodeRush.Common.Version AssemblyVersion;

		static About()
		{
			var assembly = typeof(About).Assembly;
			var version = assembly.GetName().Version;
			AssemblyVersion = new DevExpress.CodeRush.Common.Version(
				version.Major,
				version.Minor,
				version.Build,
				version.Revision,
				DevExpress.CodeRush.Common.ReleaseType.Release);
			AssemblyTitle = GetCustomAttribute<AssemblyTitleAttribute>(assembly).Title;
			AssemblyCopyright = GetCustomAttribute<AssemblyCopyrightAttribute>(assembly).Copyright;
			AssemblyDescription = GetCustomAttribute<AssemblyDescriptionAttribute>(assembly).Description;
		}

		private static T GetCustomAttribute<T>(Assembly asm) where T : Attribute
		{
			var attributes = (T[])asm.GetCustomAttributes(typeof(T), true);
			return attributes[0];
		}

		public override string Copyright1
		{
			get
			{
				return AssemblyCopyright;
			}
		}

		public override string Description
		{
			get
			{
				return AssemblyDescription;
			}
		}

		public override Guid ID
		{
			get
			{
				return ProductId;
			}
		}

		public override DevExpress.CodeRush.Common.Version MinimumEngineVersion
		{
			get
			{
				return MinEngineVersion;
			}
		}

		public override DevExpress.CodeRush.Common.ModuleTypes ModuleType
		{
			get
			{
				return DevExpress.CodeRush.Common.ModuleTypes.Free;
			}
		}

		public override string Name
		{
			get
			{
				return AssemblyTitle;
			}
		}

		public override string[] SupportedLanguages
		{
			get { throw new NotImplementedException(); }
		}

		public override DevExpress.CodeRush.Common.Version Version
		{
			get
			{
				return AssemblyVersion;
			}
		}

		protected override void BuildDefenition()
		{
			this.DefinePlugIn(PluginAssemblyName);
		}

		public override System.Drawing.Image GetImage()
		{
			Assembly current = typeof(About).Assembly;
			return new System.Drawing.Bitmap(current.GetManifestResourceStream(LogoPath));
		}
	}
}
