﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using DevExpress.CodeRush.Common;

// TODO: Use the DXCoreAssemblyAttribute from your own plugin.
[assembly: DXCoreAssembly(DXCoreAssemblyType.PlugIn, "ProductModuleDemo", PlugInLoadType.Demand, LoadAbilityType.LoadEnabled)]
[assembly: DXCoreProduct(typeof(ProductModuleDemo.About))]

// TODO: Update the assembly information to be correct for your plugin.
[assembly: AssemblyTitle("Product Module Demo")]
[assembly: AssemblyCopyright("Copyright © 2010 Travis Illig")]
[assembly: AssemblyDescription("Demonstration that shows how the ProductModule works to get a plugin into the About box.")]
[assembly: AssemblyVersion("1.0.0.0")]
