﻿using System;
using System.Diagnostics;
using System.ServiceProcess;
using System.Timers;

namespace BoxedService
{
	/// <summary>
	/// "Boxed" service that does everything we like except one tiny thing
	/// we don't. We'll need to modify the runtime behavior with Typemock Isolator.
	/// </summary>
	partial class ServiceToWrap : ServiceBase
	{
		Timer _timer;

		/// <summary>
		/// Initializes a new instance of the <see cref="ServiceToWrap"/> class.
		/// </summary>
		public ServiceToWrap()
		{
			InitializeComponent();
		}

		/// <summary>
		/// Starts a timer that will access the malfunctioning component on a
		/// regular basis.
		/// </summary>
		/// <param name="args">Startup arguments.</param>
		protected override void OnStart(string[] args)
		{
			this._timer = new Timer(1000);
			this._timer.Elapsed += new ElapsedEventHandler(_timer_Elapsed);
			this._timer.Start();
		}

		/// <summary>
		/// Stops the timer.
		/// </summary>
		protected override void OnStop()
		{
			this._timer.Stop();
			this._timer.Dispose();
			this._timer = null;
		}

		/// <summary>
		/// Accesses the malfunctioning component.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">
		/// An <see cref="System.Timers.ElapsedEventArgs" /> that contains the
		/// event data.
		/// </param>
		void _timer_Elapsed(object sender, ElapsedEventArgs e)
		{
			try
			{
				// We don't actually want to stop this call from happening, we
				// just need to change how it works.
				new MalfunctioningComponent().PerformAction(DateTime.Now.Ticks.ToString());
			}
			catch (Exception err)
			{
				Trace.WriteLine(String.Format("[{0}] Exception: {1}", DateTime.Now.Ticks, err.Message));
			}
		}
	}
}
