﻿using System;
using System.ServiceProcess;

namespace BoxedService
{
	/// <summary>
	/// Main entry point for the boxed service.
	/// </summary>
	public static class Program
	{
		/// <summary>
		/// Main program entry point - we need to replicate this in our wrapper.
		/// </summary>
		public static void Main()
		{
			ServiceToWrap svc = new ServiceToWrap();
			ServiceBase.Run(svc);
		}
	}
}
