﻿using System;

namespace BoxedService
{
	/// <summary>
	/// This represents a component that has a method that isn't behaving quite
	/// right. We will replace that behavior at runtime with Typemock Isolator.
	/// </summary>
	public class MalfunctioningComponent
	{
		/// <summary>
		/// Performs some sort of action that we don't like. We will replace the
		/// behavior with Typemock Isolator.
		/// </summary>
		/// <param name="parameter">
		/// A parameter that will be used in the action.
		/// </param>
		public void PerformAction(string parameter)
		{
			// We'll emulate a malfunction by throwing an exception.
			throw new InvalidOperationException("This component is malfunctioning! It needs to be fixed!");
		}
	}
}
