﻿using System;
using System.ComponentModel;
using System.Configuration.Install;

namespace BoxedService
{
	/// <summary>
	/// Installer for the boxed service.
	/// </summary>
	[RunInstaller(true)]
	public partial class ProjectInstaller : Installer
	{
		/// <summary>
		/// Initializes a new instance of the <see cref="ProjectInstaller"/> class.
		/// </summary>
		public ProjectInstaller()
		{
			InitializeComponent();
		}
	}
}
