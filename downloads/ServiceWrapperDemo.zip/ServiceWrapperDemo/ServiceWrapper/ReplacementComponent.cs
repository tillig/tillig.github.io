﻿using System;
using System.Diagnostics;

namespace ServiceWrapper
{
	/// <summary>
	/// Performs "replacement" behavior for the
	/// <see cref="BoxedService.MalfunctioningComponent"/>
	/// </summary>
	public class ReplacementComponent
	{
		/// <summary>
		/// Replacement for the
		/// <see cref="BoxedService.MalfunctioningComponent.PerformAction"/> method.
		/// </summary>
		/// <param name="parameter">
		/// A parameter that will be used in the action.
		/// </param>
		public void PerformAction(string parameter)
		{
			Trace.WriteLine("Intercepted message: " + parameter);
		}
	}
}
