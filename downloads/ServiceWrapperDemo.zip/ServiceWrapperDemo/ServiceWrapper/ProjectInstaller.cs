﻿using System;
using System.ComponentModel;
using System.Configuration.Install;

namespace ServiceWrapper
{
	/// <summary>
	/// Installer for the wrapped service.
	/// </summary>
	[RunInstaller(true)]
	public partial class ProjectInstaller : Installer
	{
		/// <summary>
		/// Initializes a new instance of the <see cref="ProjectInstaller"/> class.
		/// </summary>
		public ProjectInstaller()
		{
			InitializeComponent();

			// Change the credentials here to be for a user that has Typemock
			// Isolator enabled. That user should have the following environment
			// variables on their user profile:
			// Cor_Enable_Profiling=0x1
			// COR_PROFILER={B146457E-9AED-4624-B1E5-968D274416EC}
			this.serviceProcessInstaller1.Password = "password";
			this.serviceProcessInstaller1.Username = @"MACHINENAME\username";
		}
	}
}
