using System;
using System.Diagnostics;
using BoxedService;
using TypeMock.ArrangeActAssert;

namespace ServiceWrapper
{
	/// <summary>
	/// Sets up expectations and runs the wrapped service.
	/// </summary>
	public static class Program
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		public static void Main()
		{
			// This is where the magic happens - set up the Isolator
			// expectations before you pass control in to the original service.
			ExpectationSetup();

			// Pass control on to the actual service host.
			BoxedService.Program.Main();
		}

		/// <summary>
		/// Performs the Typemock Isolator expectation setup.
		/// </summary>
		public static void ExpectationSetup()
		{
			// There are many ways to set up alternate behavior in Typemock
			// Isolator; in this case, we'll ensure that any time a malfunctioning
			// component is created in the boxed service, it's replaced with a
			// specific one of our choosing. On that specific malfunctioning
			// component, we'll use Isolator's duck typing feature to just replace
			// calls on the malfunctioning component with calls to our replacement.
			ReplacementComponent replacement = new ReplacementComponent();
			MalfunctioningComponent fake = new MalfunctioningComponent();
			Isolate.Swap.AllInstances<MalfunctioningComponent>().With(fake);
			Isolate.Swap.CallsOn(fake).WithCallsTo(replacement);
		}
	}
}
