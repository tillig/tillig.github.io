using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Web.Hosting;
using System.Web.Mvc;

namespace Demo.UI
{
	/// <summary>
	/// Extension methods for the <see cref="System.Web.Mvc.ViewEngineCollection"/>
	/// used in generating demonstrations.
	/// </summary>
	public static class ViewEngineCollectionExtensions
	{
		/// <summary>
		/// Reference to the private <c>GetPath</c> method on the <see cref="System.Web.Mvc.VirtualPathProviderViewEngine"/>
		/// class. This method is how the engine locates the path to a specific
		/// partial view file.
		/// </summary>
		private static readonly MethodInfo _getPathMethod = typeof(VirtualPathProviderViewEngine).GetMethod("GetPath", BindingFlags.Instance | BindingFlags.NonPublic);

		/// <summary>
		/// Delegate used to call the <c>GetPath</c> method on an instance of
		/// <see cref="System.Web.Mvc.VirtualPathProviderViewEngine"/>.
		/// </summary>
		/// <param name="controllerContext">
		/// The <see cref="System.Web.Mvc.ControllerContext"/> for the current request.
		/// </param>
		/// <param name="locations">
		/// The locations to search. Always pass <see cref="System.Web.Mvc.VirtualPathProviderViewEngine.PartialViewLocationFormats"/>
		/// when searching for a partial view.
		/// </param>
		/// <param name="areaLocations">
		/// The area-specific locations to search. Always pass
		/// <see cref="System.Web.Mvc.VirtualPathProviderViewEngine.AreaPartialViewLocationFormats"/>
		/// when searching for a partial view.
		/// </param>
		/// <param name="locationsPropertyName">
		/// The name of the property being passed as the second parameter. Always pass
		/// <c>PartialViewLocationFormats</c> when searching for a partial view.
		/// </param>
		/// <param name="name">
		/// The name of the view/partial view to locate.
		/// </param>
		/// <param name="controllerName">
		/// The name of the controller that will host the view/partial view. Get this
		/// value from the <paramref name="controllerContext" /> route data
		/// with the key <c>controller</c>.
		/// </param>
		/// <param name="cacheKeyPrefix">
		/// The prefix used when caching view results. Always pass <c>Partial</c>
		/// when searching for a partial view.
		/// </param>
		/// <param name="useCache">
		/// <see langword="true" /> to cache results, <see langword="false" /> to skip caching.
		/// When simply locating the file, pass <see langword="false" />.
		/// </param>
		/// <param name="searchedLocations">
		/// If the view is found, this value will be <see langword="null" />; if
		/// it's not found, it will be an array of the searched locations.
		/// </param>
		/// <returns>
		/// A <see cref="System.Web.Hosting.VirtualFile"/> pointing to the
		/// located view if found, or <see langword="null" /> if not.
		/// </returns>
		private delegate string VirtualPathProviderViewEngineGetPath(ControllerContext controllerContext, string[] locations, string[] areaLocations, string locationsPropertyName, string name, string controllerName, string cacheKeyPrefix, bool useCache, out string[] searchedLocations);

		/// <summary>
		/// Locates a partial view file from a set of view engines.
		/// </summary>
		/// <param name="viewEngines">
		/// The set of view engines to search for the view.
		/// </param>
		/// <param name="controllerContext">
		/// The <see cref="System.Web.Mvc.ControllerContext"/> under which the
		/// view will be located and possibly hosted.
		/// </param>
		/// <param name="partialViewName">
		/// The name of the partial view to locate (without file extension).
		/// </param>
		/// <returns>
		/// A <see cref="System.Web.Hosting.VirtualFile"/> pointing to the
		/// located view if found, or <see langword="null" /> if not.
		/// </returns>
		/// <remarks>
		/// <para>
		/// Partial view files can only be located from view engines that derive
		/// from <see cref="System.Web.Mvc.VirtualPathProviderViewEngine"/>. If
		/// the <paramref name="viewEngines" /> collection is empty or only contains
		/// view engines that don't derive from <see cref="System.Web.Mvc.VirtualPathProviderViewEngine"/>,
		/// this method will return <see langword="null" />.
		/// </para>
		/// <para>
		/// Otherwise, for each registered view engine deriving from
		/// <see cref="System.Web.Mvc.VirtualPathProviderViewEngine"/>, the internal/private
		/// <c>GetPath</c> method is called to locate the view. This is the same
		/// method used by the framework when attempting to compile and execute
		/// the view. The first encountered matching view found will be returned.
		/// If no view engine can locate the file, this method will return <see langword="null" />.
		/// </para>
		/// </remarks>
		/// <exception cref="System.ArgumentNullException">
		/// Thrown if <paramref name="viewEngines" />, <paramref name="controllerContext" />, or <paramref name="partialViewName" /> is <see langword="null" />.
		/// </exception>
		/// <exception cref="System.ArgumentException">
		/// Thrown if <paramref name="partialViewName" /> is empty.
		/// </exception>
		/// <exception cref="System.InvalidOperationException">
		/// Thrown if the <paramref name="controllerContext" /> route data does
		/// not contain a value for <c>controller</c>.
		/// </exception>
		public static VirtualFile FindPartialViewFile(this ViewEngineCollection viewEngines, ControllerContext controllerContext, string partialViewName)
		{
			if (viewEngines == null)
			{
				throw new ArgumentNullException("viewEngines");
			}
			if (controllerContext == null)
			{
				throw new ArgumentNullException("controllerContext");
			}
			if (partialViewName == null)
			{
				throw new ArgumentNullException("partialViewName");
			}
			if (partialViewName.Length == 0)
			{
				throw new ArgumentException("Partial view name may not be empty.", "partialViewName");
			}
			foreach (var viewEngine in viewEngines)
			{
				var vppEngine = viewEngine as VirtualPathProviderViewEngine;
				if (vppEngine == null)
				{
					// We can't get a file from an engine that doesn't use VPP.
					continue;
				}

				// Create a new delegate pointing to GetPath. You have to create
				// the delegate each time because it's an instance method that
				// must be targeted to the specific engine instance.
				var getPathDelegate = (VirtualPathProviderViewEngineGetPath)Delegate.CreateDelegate(typeof(VirtualPathProviderViewEngineGetPath), vppEngine, _getPathMethod);

				// Call GetPath to get the virtual path to the view if it can
				// be located.
				string[] searchedLocations = null;
				var path = getPathDelegate(controllerContext, vppEngine.PartialViewLocationFormats, vppEngine.AreaPartialViewLocationFormats, "PartialViewLocationFormats", partialViewName, controllerContext.RouteData.GetRequiredString("controller"), "Partial", false, out searchedLocations);

				// If GetPath returned something, the view was found, so retrieve
				// the file from the VPP and return the result.
				if (!String.IsNullOrEmpty(path))
				{
					return HostingEnvironment.VirtualPathProvider.GetFile(path);
				}
			}

			// No view engine was able to locate the virtual file so return null.
			return null;
		}
	}
}