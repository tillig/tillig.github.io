using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Web.Mvc;
using System.Web.Mvc.Html;

namespace Demo.UI
{
	/// <summary>
	/// Extension methods for <see cref="System.Web.Mvc.HtmlHelper"/> that aid
	/// in presenting the demo site.
	/// </summary>
	public static class DemoHtmlExtensions
	{
		/// <summary>
		/// Renders the specified partial view as an HTML-encoded string with demo/code tabs.
		/// </summary>
		/// <param name="htmlHelper">The <see cref="System.Web.Mvc.HtmlHelper"/> instance that this method extends.</param>
		/// <param name="partialViewName">The name of the partial view.</param>
		/// <returns>
		/// The partial view that is rendered as an HTML-encoded string including
		/// HTML for jQuery UI compatible tabs to allow the user to switch
		/// between the actual HTML and the code for the partial view.
		/// </returns>
		/// <remarks>
		/// <para>
		/// Each set of tabs will have an ID based on the name of the partial
		/// view and a GUID so they will always be unique, allowing multiple
		/// tab sets on one page. The wrapper <c>div</c> will have a class
		/// <c>demo-tabs</c> so you can initialize all of the tab sets with
		/// a simple script:
		/// </para>
		/// <code>
		/// &lt;script type=&quot;text/javascript&quot;&gt;
		/// $(function () {
		///   $(&quot;.demo-tabs&quot;).tabs();
		/// });
		/// &lt;/script&gt;
		/// </code>
		/// </remarks>
		/// <exception cref="System.ArgumentNullException">
		/// Thrown if <paramref name="htmlHelper" /> or <paramref name="partialViewName" /> is <see langword="null" />.
		/// </exception>
		/// <exception cref="System.ArgumentException">
		/// Thrown if <paramref name="partialViewName" /> is empty.
		/// </exception>
		public static MvcHtmlString DemoPartial(this HtmlHelper htmlHelper, string partialViewName)
		{
			if (htmlHelper == null)
			{
				throw new ArgumentNullException("htmlHelper");
			}
			return htmlHelper.DemoPartial(partialViewName, null, htmlHelper.ViewData);
		}

		/// <summary>
		/// Renders the specified partial view as an HTML-encoded string with demo/code tabs.
		/// </summary>
		/// <param name="htmlHelper">The <see cref="System.Web.Mvc.HtmlHelper"/> instance that this method extends.</param>
		/// <param name="partialViewName">The name of the partial view.</param>
		/// <param name="model">The model for the partial view.</param>
		/// <returns>
		/// The partial view that is rendered as an HTML-encoded string including
		/// HTML for jQuery UI compatible tabs to allow the user to switch
		/// between the actual HTML and the code for the partial view.
		/// </returns>
		/// <remarks>
		/// <para>
		/// Each set of tabs will have an ID based on the name of the partial
		/// view and a GUID so they will always be unique, allowing multiple
		/// tab sets on one page. The wrapper <c>div</c> will have a class
		/// <c>demo-tabs</c> so you can initialize all of the tab sets with
		/// a simple script:
		/// </para>
		/// <code>
		/// &lt;script type=&quot;text/javascript&quot;&gt;
		/// $(function () {
		///   $(&quot;.demo-tabs&quot;).tabs();
		/// });
		/// &lt;/script&gt;
		/// </code>
		/// </remarks>
		/// <exception cref="System.ArgumentNullException">
		/// Thrown if <paramref name="htmlHelper" /> or <paramref name="partialViewName" /> is <see langword="null" />.
		/// </exception>
		/// <exception cref="System.ArgumentException">
		/// Thrown if <paramref name="partialViewName" /> is empty.
		/// </exception>
		public static MvcHtmlString DemoPartial(this HtmlHelper htmlHelper, string partialViewName, object model)
		{
			if (htmlHelper == null)
			{
				throw new ArgumentNullException("htmlHelper");
			}
			return htmlHelper.DemoPartial(partialViewName, model, htmlHelper.ViewData);
		}

		/// <summary>
		/// Renders the specified partial view as an HTML-encoded string with demo/code tabs.
		/// </summary>
		/// <param name="htmlHelper">The <see cref="System.Web.Mvc.HtmlHelper"/> instance that this method extends.</param>
		/// <param name="partialViewName">The name of the partial view.</param>
		/// <param name="viewData">The view data dictionary for the partial view.</param>
		/// <returns>
		/// The partial view that is rendered as an HTML-encoded string including
		/// HTML for jQuery UI compatible tabs to allow the user to switch
		/// between the actual HTML and the code for the partial view.
		/// </returns>
		/// <remarks>
		/// <para>
		/// Each set of tabs will have an ID based on the name of the partial
		/// view and a GUID so they will always be unique, allowing multiple
		/// tab sets on one page. The wrapper <c>div</c> will have a class
		/// <c>demo-tabs</c> so you can initialize all of the tab sets with
		/// a simple script:
		/// </para>
		/// <code>
		/// &lt;script type=&quot;text/javascript&quot;&gt;
		/// $(function () {
		///   $(&quot;.demo-tabs&quot;).tabs();
		/// });
		/// &lt;/script&gt;
		/// </code>
		/// </remarks>
		/// <exception cref="System.ArgumentNullException">
		/// Thrown if <paramref name="htmlHelper" /> or <paramref name="partialViewName" /> is <see langword="null" />.
		/// </exception>
		/// <exception cref="System.ArgumentException">
		/// Thrown if <paramref name="partialViewName" /> is empty.
		/// </exception>
		public static MvcHtmlString DemoPartial(this HtmlHelper htmlHelper, string partialViewName, ViewDataDictionary viewData)
		{
			if (htmlHelper == null)
			{
				throw new ArgumentNullException("htmlHelper");
			}
			return htmlHelper.DemoPartial(partialViewName, null, viewData);
		}

		/// <summary>
		/// Renders the specified partial view as an HTML-encoded string with demo/code tabs.
		/// </summary>
		/// <param name="htmlHelper">The <see cref="System.Web.Mvc.HtmlHelper"/> instance that this method extends.</param>
		/// <param name="partialViewName">The name of the partial view.</param>
		/// <param name="model">The model for the partial view.</param>
		/// <param name="viewData">The view data dictionary for the partial view.</param>
		/// <param name="codeOnly">
		/// <see langword="true" /> if the rendering of the partial view should be skipped
		/// (display the code only, not the rendered result); <see langword="false" />
		/// to render the partial view HTML and display the code. Defaults to
		/// <see langword="false" />.
		/// </param>
		/// <returns>
		/// The partial view that is rendered as an HTML-encoded string including
		/// HTML for jQuery UI compatible tabs to allow the user to switch
		/// between the actual HTML and the code for the partial view.
		/// </returns>
		/// <remarks>
		/// <para>
		/// Each set of tabs will have an ID based on the name of the partial
		/// view and a GUID so they will always be unique, allowing multiple
		/// tab sets on one page. The wrapper <c>div</c> will have a class
		/// <c>demo-tabs</c> so you can initialize all of the tab sets with
		/// a simple script:
		/// </para>
		/// <code>
		/// &lt;script type=&quot;text/javascript&quot;&gt;
		/// $(function () {
		///   $(&quot;.demo-tabs&quot;).tabs();
		/// });
		/// &lt;/script&gt;
		/// </code>
		/// </remarks>
		/// <exception cref="System.ArgumentNullException">
		/// Thrown if <paramref name="htmlHelper" /> or <paramref name="partialViewName" /> is <see langword="null" />.
		/// </exception>
		/// <exception cref="System.ArgumentException">
		/// Thrown if <paramref name="partialViewName" /> is empty.
		/// </exception>
		public static MvcHtmlString DemoPartial(this HtmlHelper htmlHelper, string partialViewName, object model, ViewDataDictionary viewData, bool codeOnly = false)
		{
			if (htmlHelper == null)
			{
				throw new ArgumentNullException("htmlHelper");
			}
			if (partialViewName == null)
			{
				throw new ArgumentNullException("partialViewName");
			}
			if (partialViewName.Length == 0)
			{
				throw new ArgumentException("Partial view name may not be empty.", "partialViewName");
			}
			var tabSetName = HtmlHelper.GenerateIdFromName(String.Format(CultureInfo.InvariantCulture, "{0}-{1}", partialViewName, Guid.NewGuid()));
			using (var writer = new StringWriter(CultureInfo.InvariantCulture))
			{
				writer.WriteLine("<div class=\"demo-tabs\"><ul><li><a href=\"#{0}-1\">Demo</a></li><li><a href=\"#{0}-2\">Code</a></li></ul><div id=\"{0}-1\">", tabSetName);
				if (codeOnly)
				{
					writer.WriteLine("[View included for code only; switch to the code tab.]");
				}
				else
				{
					writer.WriteLine(htmlHelper.Partial(partialViewName, model, viewData));
				}
				writer.WriteLine("</div><div id=\"{0}-2\">", tabSetName);
				var partialViewFile = ViewEngines.Engines.FindPartialViewFile(htmlHelper.ViewContext.Controller.ControllerContext, partialViewName);
				if (partialViewFile != null)
				{
					string brush = null;
					switch (Path.GetExtension(partialViewFile.Name).ToUpperInvariant())
					{
						case ".CSHTML":
							brush = "razor";
							break;
						default:
							brush = "html";
							break;
					}
					writer.Write("<pre class=\"brush: {0}\">", brush);
					using (var reader = new StreamReader(partialViewFile.Open()))
					{
						writer.WriteLine(htmlHelper.Encode(reader.ReadToEnd()));
					}
					writer.WriteLine("</pre>");
				}
				else
				{
					writer.WriteLine("<p>[Demo code file not available. Please see original source.]</p>");
				}
				writer.WriteLine("</div></div>");
				return MvcHtmlString.Create(writer.ToString());
			}
		}
	}
}