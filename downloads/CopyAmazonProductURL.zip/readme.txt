Copy Amazon Product URL Bookmarklet
by Travis Illig

Installation

1) Drop the .url file in it into your Favorites folder.
2) Open up the file in Notepad.  You'll find a really long line (line 4) that starts out like this:
      URL=javascript:aid='mhsvortex';if(!window...
   Change the value of 'aid' to be your Amazon Associate ID.  (By default it's mine - mhsvortex.)
3) That's it - you're ready to go.


Usage

1) Navigate to a product page on Amazon that you want an Associate link to.
2) Select the bookmarklet from your Favorites list.  It will automatically parse the URL and create a product link using the product's ASIN and your Associate ID.  You will get an alert message telling you what link got copied to your clipboard.
3) Paste the URL wherever you want to use it.
4) If you try the bookmarklet on a non-product page or on a non-Amazon site, it'll prompt you for the ASIN of the product you want to link to.


License
FREE. Use at your own risk, no support available, no responsibility on my part if your machine gets hosed (even if I can't forsee anything actually happening from a *bookmarklet*).
