using System;

namespace EnumSwitcharoo
{
	class Program
	{
		/// <summary>
		/// Program to demonstrate the "enumeration value switcharoo."
		/// </summary>
		/// <param name="args">Command line arguments</param>
		/// <remarks>
		/// <para>
		/// To see the "enumeration value switcharoo" in action:
		/// </para>
		/// <list type="number">
		/// <item>
		/// <term>
		/// Compile the main program ("EnumSwitcharoo") and the external dependency
		/// assembly ("ExternalDependency").  Run the program as-is.  Notice that
		/// the value you're switching on and the value that was seen in the switch
		/// statement are the same.
		/// </term>
		/// </item>
		/// <item>
		/// <term>
		/// Copy the main program to another folder.  The idea here is to simulate
		/// what happens if a third party dependency changes but the main program
		/// doesn't.
		/// </term>
		/// </item>
		/// <item>
		/// <term>
		/// Reorder the enumeration in the external dependency assembly.  Make
		/// it something like "Second," "Third," "First."
		/// </term>
		/// </item>
		/// <item>
		/// <term>
		/// Rebuild the external dependency assembly and put it in the folder where
		/// you copied the original build of the main program.
		/// </term>
		/// </item>
		/// <item>
		/// <term>
		/// Run the program with the new build of the external dependency.  Note
		/// that the string value seen in the first line written to the console
		/// doesn't actually match what the value seen by the switch statement is.
		/// </term>
		/// </item>
		/// </list>
		/// </remarks>
		static void Main(string[] args)
		{
			// Explicitly choose the first value in the enumeration so we know
			// exactly what we're working with.
			ExternalDependency.ExternalEnumeration value = ExternalDependency.ExternalEnumeration.First;
			Console.WriteLine("The value we're switching on is '{0}.'", value);

			// Run the value through a switch statement so we can see what a non-string
			// related statement will see.
			string switched = "";
			switch (value)
			{
				case ExternalDependency.ExternalEnumeration.First:
					switched = "First";
					break;
				case ExternalDependency.ExternalEnumeration.Second:
					switched = "Second";
					break;
				case ExternalDependency.ExternalEnumeration.Third:
					switched = "Third";
					break;
			}

			// Write out what the code thought it saw - does it match the value
			// we expected?
			Console.WriteLine("The value that was detected in the switch statement is '{0}.'", switched);
		}
	}
}
