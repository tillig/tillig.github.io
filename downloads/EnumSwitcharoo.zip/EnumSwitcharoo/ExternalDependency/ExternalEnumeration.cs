using System;

namespace ExternalDependency
{
	/// <summary>
	/// Enumeration used to reproduce the "enumeration value switcharoo."
	/// </summary>
	/// <remarks>
	/// <para>
	/// Compile two different versions of the ExternalDependency assembly -
	/// one where the First, Second, and Third values are in order and one
	/// where the order is switched around.
	/// </para>
	/// <para>
	/// Run the EnumSwitcharoo application once with each version of the assembly
	/// so you can see the difference.
	/// </para>
	/// </remarks>
	public enum ExternalEnumeration
	{
		First,
		Second,
		Third
	}
}
